// ajax return
var my_module_example = function(data) {
    alert(data.msg);
}
// function mmm(nid, field, value) {
//     // ajax call
//     $.ajax({
//         type: 'POST',
//         url: '/custom_example',
//         dataType: 'json',
//         success: my_module_example,
//         data: 'js=1&my_module_post_data=2012'
//     });
// };
    function mmm(nid, field, value) {
        $.ajax({
            type: "POST",
            url: '/setField',
            dataType: 'json',
            data: {
                nid: nid,
                field: field,
                value: value
            },
            success: function(data, textStatus, jqXHR) {
               alert();
            },
            error: function(jqXHR, textStatus, errorThrown) {
              alert(textStatus, errorThrown)
            }
        }).done(function(msg) {
            alert("Data Saved: " + msg);
        });
    };